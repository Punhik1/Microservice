package com.punhik.jpadatabase.JPAConnectivity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaConnectivityApplicationTests {

	@Test
	void contextLoads() {
	}

}
